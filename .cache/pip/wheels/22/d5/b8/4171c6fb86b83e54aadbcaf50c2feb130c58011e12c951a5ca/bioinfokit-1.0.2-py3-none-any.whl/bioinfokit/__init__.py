name = "bioinfokit"
__version__ = "1.0.2"
__author__ = "Renesh Bedre"


